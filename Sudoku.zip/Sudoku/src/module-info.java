module Sudoku {
	requires java.desktop;
}