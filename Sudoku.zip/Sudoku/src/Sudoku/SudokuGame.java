package Sudoku;

import java.util.Arrays;
import java.util.Random;

public class SudokuGame {

	private char[][][] puzzleTemplate;
	private boolean[][][] masksTemplate;

	private char[][] puzzle;
	private boolean[][] masks;

	public SudokuGame() {

		puzzleTemplate = new char[][][] {
				{ 
					{ '5', '3', '4', '6', '7', '8', '9', '1', '2' }, { '6', '7', '2', '1', '9', '5', '3', '4', '8' }, { '1', '9', '8', '3', '4', '2', '5', '6', '7' },
					{ '8', '5', '9', '7', '6', '1', '4', '2', '3' }, { '4', '2', '6', '8', '5', '3', '7', '9', '1' }, { '7', '1', '3', '9', '2', '4', '8', '5', '6' },
					{ '9', '6', '1', '5', '3', '7', '2', '8', '4' }, { '2', '8', '7', '4', '1', '9', '6', '3', '5' }, { '3', '4', '5', '2', '8', '6', '1', '7', '9' } 
				},
				{ 
					{ '8', '6', '4', '9', '2', '5', '1', '3', '7' }, { '3', '5', '7', '4', '1', '8', '2', '6', '9' }, { '9', '2', '1', '6', '7', '3', '8', '4', '5' },
					{ '1', '8', '5', '2', '9', '4', '6', '7', '3' }, { '4', '3', '6', '7', '5', '1', '9', '2', '8' }, { '7', '9', '2', '3', '8', '6', '4', '5', '1' },
					{ '6', '1', '8', '5', '3', '2', '7', '9', '4' }, { '5', '4', '9', '8', '6', '7', '3', '1', '2' }, { '2', '7', '3', '1', '4', '9', '5', '8', '6' } 
				},
				{ 
					{ '9', '2', '5', '7', '3', '4', '8', '6', '1' }, { '3', '8', '6', '5', '1', '9', '4', '7', '2' }, { '7', '4', '1', '2', '8', '6', '9', '3', '5' },
					{ '1', '5', '9', '8', '2', '7', '6', '4', '3' }, { '8', '6', '7', '1', '4', '3', '5', '2', '9' }, { '4', '3', '2', '6', '9', '5', '7', '1', '8' },
					{ '2', '1', '4', '9', '6', '8', '3', '5', '7' }, { '5', '9', '3', '4', '7', '2', '1', '8', '6' }, { '6', '7', '8', '3', '5', '1', '2', '9', '4' } 
				},
				};
		masksTemplate = new boolean[][][] {
				{ { true, false, true, false, true, true, false, true, false },
						{ true, true, false, false, true, true, false, false, true },
						{ true, false, true, false, false, false, true, false, true },
						{ true, false, true, false, false, false, true, true, false },
						{ false, true, false, true, true, false, true, false, false },
						{ false, true, true, true, false, false, true, true, true },
						{ false, true, true, false, false, true, true, false, false},
						{ true, false, true, false, false, true, false, false, false },
						{ false, true, false, true, false, false, true, false, true } },
				{ { false, false, false, false, false, false, false, false, false },
						{ false, false, false, false, false, false, false, false, false },
						{ false, false, false, true, false, false, true, false, false },
						{ false, false, false, false, false, false, false, false, false },
						{ false, false, false, false, false, false, false, true, false },
						{ false, false, false, false, false, false, false, false, false },
						{ false, false, false, true, false, false, false, false, false },
						{ false, false, false, false, false, false, false, false, false },
						{ false, false, false, false, false, false, false, false, false } },
				{ { false, true, false, false, false, true, false, false, false },
						{ false, true, false, true, false, false, true, false, true },
						{ true, true, false, false, false, false, false, false, false },
						{ true, false, true, true, false, true, false, false, true },
						{ false, false, true, true, false, false, true, true, false },
						{ false, false, true, false, true, false, true, true, false },
						{ false, true, false, false, true, false, true, false, true },
						{ false, true, false, true, false, false, false, true, false },
						{ false, false, true, false, false, false, true, false, true } },
				{ { false, true, false, true, false, true, false, false, false },
						{ true, false, false, true, false, false, false, false, true },
						{ false, false, true, false, false, false, true, false, false },
						{ true, false, false, true, false, false, false, false, true },
						{ false, true, true, false, false, true, false, false, false },
						{ true, false, false, false, false, true, false, false, true },
						{ false, true, true, false, false, false, true, false, false },
						{ true, false, false, true, false, false, false, false, false },
						{ false, false, true, false, true, false, false, true, false } },

		};

		newGame();
	}

	public void newGame() {
		Random rand = new Random();
		puzzle = Arrays.stream(puzzleTemplate[rand.nextInt(3)]).map(char[]::clone).toArray(char[][]::new);
		masks = masksTemplate[rand.nextInt(3)];
		
		for (int i = 0; i < 9; i++) {
			for (int j = 0; j < 9; j++) {
				if (masks[i][j])
					puzzle[i][j] = '.';
			}
		}

	}

	public char[][] getPuzzle() {
		return puzzle;
	}

	public void setPuzzle(char[][] puzzle) {
		this.puzzle = puzzle;
	}

	public boolean[][] getMasks() {
		return masks;
	}

	public void setMasks(boolean[][] masks) {
		this.masks = masks;
	}

	public boolean isValidSudoku() {
		return isValidSudoku(puzzle);
	}

	public boolean isFinished()
	{
		for (int i = 0; i < 9; i++) {
	        for (int j = 0; j < 9; j++) {
	            if(puzzle[i][j]=='.')
	            	return false;
	        }
	    }
		return true;
	}
	
	private boolean isValidSudoku(char[][] board) {
	    if (board == null || board.length != 9 || board[0].length != 9)
	        return false;
	    // check column
	    for (int i = 0; i < 9; i++) {
	        boolean[] m = new boolean[9];
	        for (int j = 0; j < 9; j++) {
	            if (board[i][j] != '.') {
	                if (m[(int) (board[i][j] - '1')]) {
	                    return false;
	                }
	                m[(int) (board[i][j] - '1')] = true;
	            }else {
	            	return false;
	            }
	        }
	    }
	 
	    //check row
	    for (int j = 0; j < 9; j++) {
	        boolean[] m = new boolean[9];
	        for (int i = 0; i < 9; i++) {
	            if (board[i][j] != '.') {
	                if (m[(int) (board[i][j] - '1')]) {
	                    return false;
	                }
	                m[(int) (board[i][j] - '1')] = true;
	            }else {
	            	return false;
	            }
	        }
	    }
	 
	    //check  3*3 matrix
	    for (int block = 0; block < 9; block++) {
	        boolean[] m = new boolean[9];
	        for (int i = block / 3 * 3; i < block / 3 * 3 + 3; i++) {
	            for (int j = block % 3 * 3; j < block % 3 * 3 + 3; j++) {
	                if (board[i][j] != '.') {
	                    if (m[(int) (board[i][j] - '1')]) {
	                        return false;
	                    }
	                    m[(int) (board[i][j] - '1')] = true;
	                }
	            }
	        }
	    }
	 
	    return true;
	}
	
	public void setNumber(int column, int row, char number) {
		puzzle[row][column] = number;
	}

}
