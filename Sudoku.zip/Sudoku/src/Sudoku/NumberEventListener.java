package Sudoku;

import java.util.EventListener;



public interface NumberEventListener extends EventListener{

	public void NumberAdded(NumberEvent event); 
	
}
