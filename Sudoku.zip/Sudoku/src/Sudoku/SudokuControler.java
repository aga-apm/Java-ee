package Sudoku;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;

public class SudokuControler {

	private SudokuGame game;
	private SudokuGUI gui;

	public SudokuControler(SudokuGame game, SudokuGUI gui) {

		this.game = game;
		this.gui = gui;

	}

	public void run() {
		game.newGame();
		gui.drawGrid(game.getPuzzle());
		this.gui.setVisible(true);
		this.gui.setSize(600, 600);
		this.gui.getExit().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				exit();

			}
		});
		this.gui.getAbout().addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				JOptionPane.showMessageDialog(gui, "Sudoku is a logic-based, combinatorial number-placement puzzle.\n"
						+ " The objective is to fill a 9�9 grid with digits so that each column, \n each row, and each of"
						+ "the nine 3�3 subgrids that compose the grid \n contain all of the digits from 1 to 9.\n"
						+ "After typing the number, press enter to approve it.");

			}
		});
		gui.addNumberListener(new NumberEventListener() {

			@Override
			public void NumberAdded(NumberEvent event) {
				System.out.println(event.toString());
				game.setNumber(event.column, event.row, event.number);
				if(game.isFinished())
				{
					if (game.isValidSudoku()) {
						JOptionPane.showMessageDialog(gui,"Congratulations!!!  You are the winner.");
					}else {
						JOptionPane.showMessageDialog(gui,"There is mistake on the board");
					}
				}
				
			}

		});
		this.gui.getNewGame().addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				game.newGame();
				gui.drawGrid(game.getPuzzle());
				SwingUtilities.updateComponentTreeUI(gui);
			}
		});

	}

	public void exit() {
		this.gui.setVisible(false);
		this.gui.dispose();
		System.exit(0);
	}

}
