package Sudoku;

import java.awt.AWTEvent;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import javax.swing.BorderFactory;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.EventListenerList;
import javax.swing.text.NumberFormatter;

public class SudokuGUI extends JFrame {

	JMenuItem newGame;
	JMenuItem about;
	JMenuItem exit;
	protected EventListenerList listenerList = new EventListenerList();

	public static final int GRID_SIZE = 9; 
	public static final int SUBGRID_SIZE = 3; 
	public static final int CELL_SIZE = 60; 
	public static final int CANVAS_WIDTH = CELL_SIZE * GRID_SIZE;
	public static final int CANVAS_HEIGHT = CELL_SIZE * GRID_SIZE;
	
	public static final Color OPEN_CELL_BGCOLOR = Color.yellow;
	public static final Color FILLED_CELL_BGCOLOR = Color.orange;
	
	public static final Color OPEN_CELL_TEXT_YES = new Color(0, 255, 0); 
	public static final Color OPEN_CELL_TEXT_NO = Color.RED;
	public static final Color CLOSED_CELL_BGCOLOR = new Color(240, 240, 240); 
	public static final Color CLOSED_CELL_TEXT = Color.BLACK;
	public static final Font FONT_NUMBERS = new Font("Monospaced", Font.BOLD, 20);

	
	
	private JFormattedTextField[][] tfCells = new JFormattedTextField[GRID_SIZE][GRID_SIZE];

	public SudokuGUI() {
		setLayout(new GridLayout());

		this.setTitle("Sodoku Game");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);

		JMenuBar menuBar = new JMenuBar();
		JMenu jmenu = new JMenu("Game");
		this.setJMenuBar(menuBar);

		newGame = new JMenuItem("New Game");
		about = new JMenuItem("About");
		exit = new JMenuItem("Exit");

		jmenu.add(newGame);
		jmenu.add(about);
		jmenu.add(exit);
		menuBar.add(jmenu);

		pack();

	}

	public void drawGrid(char[][] puzzle) {
		Container cp = getContentPane();
		cp.setLayout(new GridLayout(GRID_SIZE, GRID_SIZE));
		NumberFormat format = NumberFormat.getInstance();
		NumberFormatter formatter = new NumberFormatter(format);
		formatter.setValueClass(Integer.class);
		formatter.setMinimum(1);
		formatter.setMaximum(9);
		formatter.setAllowsInvalid(true);
		
		formatter.setOverwriteMode(true);
		
		for (int row = 0; row < GRID_SIZE; ++row) {
			for (int col = 0; col < GRID_SIZE; ++col) {
				if (tfCells[row][col] != null) {
					cp.remove(tfCells[row][col]);
				}
				tfCells[row][col] = new JFormattedTextField(formatter);
				cp.add(tfCells[row][col]);
					
				tfCells[row][col].addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							int rowSelected = -1;
							int colSelected = -1;
							JFormattedTextField source = (JFormattedTextField) e.getSource();
							char sourseText = source.getText().charAt(0);
							boolean found = false;
							for (int row = 0; row < GRID_SIZE && !found; ++row) {
								for (int col = 0; col < GRID_SIZE && !found; ++col) {
									if (tfCells[row][col] == source) {
										rowSelected = row;
										colSelected = col;
										found = true;
									}
								}
							}
							source.setBackground(FILLED_CELL_BGCOLOR);
							dispatchEvent(new NumberEvent(this, rowSelected, colSelected, sourseText));
						}
					});
				
				if (puzzle[row][col]=='.') {
					tfCells[row][col].setText("");
					tfCells[row][col].setEditable(true);
					tfCells[row][col].setBackground(OPEN_CELL_BGCOLOR);
				} else {
					tfCells[row][col].setText(Character.toString(puzzle[row][col]));
					tfCells[row][col].setEditable(false);
					tfCells[row][col].setBackground(CLOSED_CELL_BGCOLOR);
				}
				// pogrubienie lini
				tfCells[row][col].setHorizontalAlignment(JFormattedTextField.CENTER);
				tfCells[row][col].setFont(FONT_NUMBERS);
				if (row % 3 == 0 && row > 0)
					if (col % 3 == 0 && col > 0) {
						tfCells[row][col].setBorder(BorderFactory.createMatteBorder(3, 3, 1, 1, Color.BLACK));
					} else {
						tfCells[row][col].setBorder(BorderFactory.createMatteBorder(3, 1, 1, 1, Color.BLACK));
					}
				else if (col % 3 == 0 && col > 0) {
					tfCells[row][col].setBorder(BorderFactory.createMatteBorder(1, 3, 1, 1, Color.BLACK));
				} else {
					tfCells[row][col].setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.BLACK));
				}

			}
		}
		cp.setPreferredSize(new Dimension(CANVAS_WIDTH, CANVAS_HEIGHT));
	}

	public void addNumberListener(NumberEventListener listener) {
		listenerList.add(NumberEventListener.class, listener);
	}

	public void removeNumberListener(NumberEventListener listener) {
		listenerList.remove(NumberEventListener.class, listener);
	}

	@Override
	protected void processEvent(AWTEvent e) {
		if (e instanceof NumberEvent) {
			NumberEventListener[] listeners = listenerList.getListeners(NumberEventListener.class);
			NumberEvent numberEvent = (NumberEvent) e;
			for (NumberEventListener numberEventListener : listeners) {
				numberEventListener.NumberAdded(numberEvent);
			}
		} else {
			super.processEvent(e);
		}
	}

	public JMenuItem getNewGame() {
		return newGame;
	}

	public JMenuItem getAbout() {
		return about;
	}

	public JMenuItem getExit() {
		return exit;
	}

}
