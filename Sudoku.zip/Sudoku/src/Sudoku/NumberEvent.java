package Sudoku;

import java.awt.AWTEvent;

public class NumberEvent extends AWTEvent {
	public static final int NUMBER_EVENT = AWTEvent.RESERVED_ID_MAX + 1;

	int row;
	int column;
	char number;

	public NumberEvent(Object source, int row, int column, char number) {
		super(source, NUMBER_EVENT);
		this.row = row;
		this.column = column;
		this.number = number;

	}

	@Override
	public String toString() {
		return "NumberEvent [row=" + row + ", column=" + column + ", number=" + number + "]";
	}

	public int getRow() {
		return row;
	}

	public int getColumn() {
		return column;
	}

	public char getNumber() {
		return number;
	}

}
