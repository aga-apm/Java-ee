package Sudoku;

import javax.swing.SwingUtilities;

public class SudokuApp {

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
			 SudokuGame game = new SudokuGame();
			 SudokuGUI gui = new SudokuGUI();
			 SudokuControler controller = new SudokuControler(game, gui);
			 
			 controller.run();
			 
			}
		});
		
		
	}

}
